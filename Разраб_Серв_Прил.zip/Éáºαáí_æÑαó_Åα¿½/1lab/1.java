import java.util.Date;
public class Main {
    
    public static void main(String[] args) {
 
        book[] stu = new book[16];
        stu[0] = new book(1, "Kayaliev", "Enver", "Islyamovich", new Date(2000, 4, 3), "Издательство 1", 400, "1400", "Мягкий");
        stu[1] = new book(2, "Dzabarov", "'Eldar'", "Abdurashidovich", new Date(1985, 7, 2), "Издательство 2", 350, "1600", "Мягкий");
        stu[2] = new book(3, "Ismailov", "Ali", "Iskanderovich", new Date(1996, 6, 24), "Издательство 3", 370, "1200", "Мягкий");
        stu[3] = new book(4, "Ametov", "Nazim", "Abdumalikovich", new Date(1999, 10, 14), "Издательство 4", 250, "1300", "Мягкий");
        stu[4] = new book(5, "Kayaliev", "Enver", "Islyamovich", new Date(2000, 4, 3), "Издательство 1", 400, "1400", "Твердый");
        stu[5] = new book(6, "Dzabarov", "'Eldar'", "Abdurashidovich", new Date(1985, 7, 2), "Издательство 2", 350, "1600", "Твердый");
        stu[6] = new book(7, "Ismailov", "Ali", "Iskanderovich", new Date(1996, 6, 24), "Издательство 3", 370, "1200", "Твердый");
        stu[7] = new book(8, "Ametov", "Nazim", "Abdumalikovich", new Date(1999, 10, 14), "Издательство 4", 250, "1300", "Твердый");
        stu[8] = new book(9, "Kayaliev", "Enver", "Islyamovich", new Date(2000, 4, 3), "Издательство 1", 400, "1400", "Скрепление на пружину");
        stu[9] = new book(10, "Dzabarov", "'Eldar'", "Abdurashidovich", new Date(1985, 7, 2), "Издательство 2", 350, "1600", "Скрепление на пружину");
        stu[10] = new book(11, "Ismailov", "Ali", "Iskanderovich", new Date(1996, 6, 24), "Издательство 3", 370, "1200", "Скрепление на пружину");
        stu[11] = new book(12, "Ametov", "Nazim", "Abdumalikovich", new Date(1999, 10, 14), "Издательство 4", 250, "1300", "Скрепление на пружину");
        stu[12] = new book(13, "Kayaliev", "Enver", "Islyamovich", new Date(2000, 4, 3), "Издательство 1", 400, "1400", "Скрепление скобой");
        stu[13] = new book(14, "Dzabarov", "'Eldar'", "Abdurashidovich", new Date(1985, 7, 2), "Издательство 2", 350, "1600", "Скрепление скобой");
        stu[14] = new book(15, "Ismailov", "Ali", "Iskanderovich", new Date(1996, 6, 24), "Издательство 3", 370, "1200", "Скрепление скобой");
        stu[15] = new book(16, "Ametov", "Nazim", "Abdumalikovich", new Date(1999, 10, 14), "Издательство 4", 250, "1300", "Скрепление скобой");
 
        Date p=new Date(1998, 10, 14);
        
        for (int i = 0; i <= 3; i++) {
            stu[i].show();
        }
//вывод на экран 
        System.out.println();
        for (int i = 0; i <= 3; i++) {
            stu[i].id();
        }
        System.out.println();
        for (int i = 0; i <= 3; i++) {
            stu[i].izdat();
        }
        System.out.println();
        for (int i = 0; i <= 3; i++) {
        stu[i].date_izdat(p);
        }
    }
}
// создаем класс
class book {
 
    public int id;
    public String surname;
    public String name;
    public String otchestva;
    public Date data_izd;
    public String izdat;
    public int kolstr;
    public String price;
    public String perepl;

 
    public book() {
    }
 
    public book(int id, String surname, String name, String otchestva, Date data_izd, String izdat, int kolstr, String price, String perepl) {
        this.id = id;
        this.surname = surname;
        this.name = name;
        this.otchestva = otchestva;
        this.data_izd = data_izd;
        this.izdat = izdat;
        this.kolstr = kolstr;
        this.price = price;
        this.perepl = perepl;
    }
 
    public String getizdat() {
        return izdat;
    }
 
    public Date getdata_izd() {
        return data_izd;
    }
 
    public String getprice() {
        return price;
    }
 
    public int getId() {
        return id;
    }
 
    public String getperepl() {
        return perepl;
    }
 
    public String getName() {
        return name;
    }
 
    public String getOtchestva() {
        return otchestva;
    }
 
    public String getSurname() {
        return surname;
    }
 
    public int getkolstr() {
        return kolstr;
    }
 
    public void setizdat(String izdat) {
        this.izdat = izdat;
    }
 
    public void setdata_izd(Date data_izd) {
        this.data_izd = new Date(1999, 9, 9);
    }
 
    public void setprice(String price) {
        this.price = price;
    }
 
    public void setId(int id) {
        this.id = id;
    }
 
    public void setperepl(String perepl) {
        this.perepl = perepl;
    }
 
    public void setName(String name) {
        this.name = name;
    }
 
    public void setOtchestva(String otchestva) {
        this.otchestva = otchestva;
    }
 
    public void setSurname(String surname) {
        this.surname = surname;
    }
 
    public void setkolstr(int kolstr) {
        this.kolstr = kolstr;
    }
 
    public void show() {
        System.out.println("id: " + getId());
        System.out.println("Familya: " + getSurname());
        System.out.println("Imya: " + getName());
        System.out.println("Otchestva: " + getOtchestva());
        System.out.println("data rojdeniya: " + getdata_izd().getYear()+"."+getdata_izd().getMonth()+"."+getdata_izd().getDay());
        System.out.println("izdat: " + getizdat());
        System.out.println("kolstr: " + getkolstr());
        System.out.println("price: " + getprice());
        System.out.println("perepl: " + getperepl());
 
 
    }
//список книг заданного автора
    public void id() {
        if (((this.getprice()).equals("1")) && (this.getId() == 1)) {
            System.out.println("id: " + getId());
            System.out.println("Familya: " + getSurname());
            System.out.println("Imya: " + getName());
            System.out.println("Otchestva: " + getOtchestva());
            System.out.println("data rojdeniya: " + getdata_izd().getYear()+"."+getdata_izd().getMonth()+"."+getdata_izd().getDay());
            System.out.println("izdat: " + getizdat());
            System.out.println("kolstr: " + getkolstr());
            System.out.println("price: " + getprice());
            System.out.println("perepl: " + getperepl());
 
        }
 
    }
//список книг выпущенных заданным издательством
    public void izdat() {
        if (((this.getizdat()).equals("Издательство 2")) && (this.getperepl() == 2)) {
            System.out.println("id: " + getId());
            System.out.println("Familya: " + getSurname());
            System.out.println("Imya: " + getName());
            System.out.println("Otchestva: " + getOtchestva());
            System.out.println("data rojdeniya: " + getdata_izd().getYear()+"."+getdata_izd().getMonth()+"."+getdata_izd().getDay());
            System.out.println("izdat: " + getizdat());
            System.out.println("kolstr: " + getkolstr());
            System.out.println("price: " + getprice());
            System.out.println("perepl: " + getperepl());
        }
    }
    //список книг после заданного года
    public void date_izdat(Date p){
    if ((this.getdata_izd().getYear()) > (p.getYear())){
    System.out.println("id: " + getId());
            System.out.println("Familya: " + getSurname());
            System.out.println("Imya: " + getName());
            System.out.println("Otchestva: " + getOtchestva());
            System.out.println("data rojdeniya: " + getdata_izd().getYear());
            System.out.println("izdat: " + getizdat());
            System.out.println("kolstr: " + getkolstr());
            System.out.println("price: " + getprice());
            System.out.println("perepl: " + getperepl());
    }
 }
}